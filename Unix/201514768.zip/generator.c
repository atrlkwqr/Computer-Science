#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


int main(int argc, char* argv[]) {

    char* names[10] = {"Alice", "Bob", "Chris", "Dod", "Evan", "Fint", "Gregg", "Brendan", "Roy", "Susan"};

    typedef struct pscore
    {
        int num;
        char nme[10];
        float sc1;
        float sc2;
        float sum;
    } student;

    FILE *fp;
    int i;
    student data[1000];

    // generate random numbers from 0 ~ 1000
    srand((unsigned int)time(NULL));
    int random = rand() % 1001;

    if(argc != 2){
        printf("error");
        return 1;
    }

    if((fp = fopen(argv[1], "w")) == NULL){
        perror("Open");
        exit(1);
    }


    // generate random student data
    for(int i = 0; i < random; i++){
        int randomNm = rand() % 10;
        int randomSc1 = rand() % 101;
        int randomSc2 = rand() % 101;

        printf("%d\n", randomSc1);

        data[i].num = i;
        strcpy(data[i].nme, names[randomNm]);
        data[i].sc1 = randomSc1;
        data[i].sc2 = randomSc2;
        data[i].sum = randomSc1 + randomSc2;

        // save as binary file
        fwrite(&data[i], sizeof(student), 1, fp);

    }
    

    fclose(fp);

    return 0;
}