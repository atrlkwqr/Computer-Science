#include <stdio.h>
#include <stdlib.h>


typedef struct pscore
{
    int num;
    char nme[10];
    float sc1;
    float sc2;
    float sum;
    struct pscore *next;
} student;


int main(int argc, char* argv[]){

    FILE *fp;
    student *head, *cur, *data, *prev;

    if(argc != 2){
        printf("error");
        return 1;
    }
    if((fp = fopen(argv[1], "r")) == NULL){
        perror("Open");
        exit(1);
    }

    // linked list
    cur = (student*) malloc(sizeof(student));
    head = cur;
    prev = cur;
    cur->next = NULL;

    while(fread(cur, 28, 1, fp) == 1){
        cur -> next = (student*)malloc(sizeof(student));
        prev = cur;
        cur = cur->next;
        cur->next = NULL;
    }

    free(cur);
    prev->next = NULL;

    printf("%p %p\n", cur, head);
    if(head == cur) head = NULL;


    cur = head;

    // Node traversal
    while(cur != NULL) {
        fprintf(stdout, "%s %d %f %f %f\n", cur->nme, cur->num, cur->sc1, cur->sc2, cur->sum);
        prev = cur;
        cur = cur->next;
        free(prev);
    }

    fclose(fp);

    return 0;
}