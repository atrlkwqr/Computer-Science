#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/shm.h>
#include <signal.h>

#define BUFSIZE (80)

void sighandler(int signum)
{
    if(signum == SIGUSR1){
        printf("succcess\n");
    }
    else{
        printf("fail\n");
    }
}

int main(int argc, char* argv[]){

    key_t key;
    int shmid, size;
    char buf[BUFSIZE];
    void *shmaddr;
    sigset_t set_to_block;
 
    struct sigaction sa2;
    sa2.sa_handler = sighandler;
    sa2.sa_flags=0;
    sigemptyset(&sa2.sa_mask);

    key = ftok("shmfile", 1);
    size = sysconf(_SC_PAGESIZE);
    shmid = shmget(key, size, IPC_CREAT|0666);

    //공유 메모리 공간 연결
    shmaddr = shmat(shmid, NULL, 0);

    //parent에게 SIGUSR1을 받아 공간이 할당되었음을 확인
    signal(SIGUSR1, sighandler);
    printf("receive SIGUSR1\n");
    //SIGUSR1를 제외한 모든 시그널 block
    sigemptyset(&set_to_block);
    sigaddset(&set_to_block, SIGUSR1);
    sigprocmask(SIG_UNBLOCK, &set_to_block, NULL);

    memcpy(buf, shmaddr, BUFSIZE);
    printf("Client: %s\n", buf);

    //shmfile 읽어오기
    FILE *fp = fopen("shmfile", "r");
    fgets(buf, BUFSIZE, fp); 

    //buf의 문자열을 공유 메모리 공간으로 복사
    memcpy(shmaddr, buf, BUFSIZE);


    //parent에게 SIGUSR2을 보내 공유 메모리 공간에 복사했음을 알림
    sigaction(SIGUSR2,&sa2,NULL);
    printf("send SIGUSR2\n");

    shmdt(shmaddr);

    return 0;
}